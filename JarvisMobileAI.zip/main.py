
from ai_chat import chat_with_ai
from reminder import set_reminder
from voice import speak, listen

def main():
    speak("Sir, Jarvis ready hai. Aapka hukm?")
    while True:
        command = listen()
        if "band ho ja" in command:
            speak("Jarvis shutting down, Sir.")
            break
        elif "reminder" in command:
            speak("Kya kaam yaad dilana hai aur kis time par?")
            task = listen()
            speak("Kaunse time par yaad dilana hai? Example: 07:00")
            time = listen()
            set_reminder(time, task)
        else:
            response = chat_with_ai(command)
            speak(response)

if __name__ == "__main__":
    main()


import datetime
import threading
from voice import speak

def set_reminder(time_str, task):
    def check():
        while True:
            now = datetime.datetime.now().strftime("%H:%M")
            if now == time_str:
                speak(f"Sir, {task} karne ka time ho gaya hai.")
                break
    threading.Thread(target=check).start()

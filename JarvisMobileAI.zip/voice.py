
import speech_recognition as sr
from gtts import gTTS
from playsound import playsound
import random
import os

def listen():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        audio = recognizer.listen(source)
    try:
        return recognizer.recognize_google(audio, language='hi-IN').lower()
    except:
        return "kshama karein, nahi sun paya."

def speak(text):
    print("JARVIS:", text)
    tts = gTTS(text=text, lang='hi')
    filename = f"voice_{random.randint(1000,9999)}.mp3"
    tts.save(filename)
    playsound(filename)
    os.remove(filename)
